package com.example.SPModular;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.SPModular.ipconexion.Direccion;

import org.json.JSONObject;

public class NuevoUsuarioActivity extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener {
    private EditText camponombre, campoapellido, campofecha, campocelular, campocontraseña;

    //Conexion directa con el webservice php
    RequestQueue requestQueue;
    JsonObjectRequest jsonObjectRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_usuario);

        camponombre = findViewById(R.id.EtxtNombre);
        campoapellido = findViewById(R.id.EtxtApellido);
        campofecha = findViewById(R.id.EtxtFecha);
        campocelular = findViewById(R.id.EtxTelefono);
        campocontraseña = findViewById(R.id.EtxContraseña);

        requestQueue = Volley.newRequestQueue(this);
    }

    private void insertarDatos() {
        String url;
        String saldo = "0";
        int idusuarios = 1;

        if (!camponombre.getText().toString().isEmpty() && !campoapellido.getText().toString().isEmpty() && !campofecha.getText().toString().isEmpty() && !campocelular.getText().toString().isEmpty() && !campocontraseña.getText().toString().isEmpty()) {
            try {
                url = Direccion.id_webservice + "insertar.php?nombre_usuario=" + camponombre.getText().toString() +
                        "&apellido_usuario=" + campoapellido.getText().toString() +
                        "&fecha_nacimiento=" + campofecha.getText().toString() +
                        "&celular_usuario=" + campocelular.getText().toString() +
                        "&password_usuario=" + campocontraseña.getText().toString() +
                        "&saldo_usuario=" + saldo +
                        "&id_empleado=" + Integer.parseInt(idusuarios + "") +
                        "&id_tipo_usuario=" + Integer.parseInt(idusuarios + "") +
                        "&id_detalle_recarga=" + Integer.parseInt(idusuarios + "");
                jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
                requestQueue.add(jsonObjectRequest);
            } catch (Exception e) {
                Toast.makeText(this, "Error Desconocido", Toast.LENGTH_SHORT).show();
                System.out.println(e.getMessage());
            }
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Alerta");
            builder.setMessage("Se necesitan llenar todos los campos para crear el usuario.");
            builder.setPositiveButton("Ok", null);
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }


    public void BotonesNUsuario(View view) {
        switch (view.getId()) {
            case R.id.btnGuardarNUsuario:
                insertarDatos();
                break;
            case R.id.btnSalirNUsuario:
                finish();
                break;
        }
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        Toast.makeText(this, "Error referente a " + error, Toast.LENGTH_SHORT).show();
        System.err.println("----------------" + error);
    }

    @Override
    public void onResponse(JSONObject response) {
        Toast.makeText(this, "Datos Guardados", Toast.LENGTH_SHORT).show();
        camponombre.setText("");
        campoapellido.setText("");
        campofecha.setText("");
        campocelular.setText("");
        campocontraseña.setText("");
    }
}

