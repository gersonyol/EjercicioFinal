package com.example.SPModular.ipconexion;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class DatosLogin extends StringRequest {
    private static final String LOGIN_REQUEST_URL = Direccion.id_webservice+"loginprueba.php";
    private Map<String, String> params;

    public DatosLogin(String correo, String contraseña, Response.Listener<String> listener) {
        super(Method.POST, LOGIN_REQUEST_URL, listener, null);
        params = new HashMap<>();
        params.put("mail_empleado", correo);
        params.put("passwd_empleado", contraseña);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }

}
