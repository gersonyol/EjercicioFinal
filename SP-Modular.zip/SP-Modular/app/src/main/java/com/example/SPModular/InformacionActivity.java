package com.example.SPModular;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class InformacionActivity extends AppCompatActivity {

    private String nombre, correo, telefono, password;


    private TextView Nombre, Correo, Telefono, Password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informacion);
        recepcionDatos();

        Nombre = findViewById(R.id.NombreEmpleado);
        Correo = findViewById(R.id.CorreoUsuario);
        Telefono= findViewById(R.id.TelefonoUsuario);
        Password= findViewById(R.id.PwdUsuario);


        MostrarInfo();

    }

    public void recepcionDatos (){
        Bundle bundle = getIntent().getExtras();
        nombre= bundle.getString("nombre");
        correo = bundle.getString("correo");
        telefono = bundle.getString("telefono");
        password = bundle.getString("password");
    }

    public void MostrarInfo (){

        Nombre.setText(nombre);
        Correo.setText(correo);
        Telefono.setText(telefono);
        Password.setText(password);

    }
}
