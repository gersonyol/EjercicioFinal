package com.example.SPModular.ipconexion;

public class Direccion {
    public static final String id_webservice="https://servidor-app2.azurewebsites.net/WebService/";
    //public static final String id_webservice="http://192.168.1.4/WebService/";
}
