package com.example.SPModular;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class PrincipalActivity extends AppCompatActivity {

    Toolbar toolbar;
    private String nombre, correo, telefono, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        Bundle bundle = getIntent().getExtras();
        nombre= bundle.getString("nombre");

        toolbar=findViewById(R.id.toolbarprincipal);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Bienvenido "+ nombre);


    }

        public void recepciondatosInfo(){
        Intent Informacion = new Intent(getApplicationContext(), InformacionActivity.class);
        Bundle bundle = getIntent().getExtras();
        nombre= bundle.getString("nombre");
        correo = bundle.getString("correo");
        telefono = bundle.getString("telefono");
        password = bundle.getString("password");

        Informacion.putExtra("nombre", nombre);
        Informacion.putExtra("correo", correo);
        Informacion.putExtra("telefono", telefono);
        Informacion.putExtra("password", password);

        startActivity(Informacion);
    }

    public void BotonesMenu(View view) {

        switch (view.getId()) {
            case R.id.btnInformacion:
                recepciondatosInfo();
                break;

            case R.id.btnRecarga:
                Intent contactanos = new Intent(getApplicationContext(), NuevoUsuarioActivity.class);
                startActivity(contactanos);
                break;
        }
    }
}
