package com.example.SPModular;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.example.SPModular.ipconexion.DatosLogin;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    EditText campocorreo, campocontraseñaI;
    CheckBox mostrarclave;
    Toolbar toolbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        campocorreo = findViewById(R.id.txtcorreoI);
        campocontraseñaI = findViewById(R.id.txtcontraseñaI);
        mostrarclave = findViewById(R.id.MostrarClave);

        toolbar = findViewById(R.id.toolbarInicio);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("PF-MODULAR");


        mostrarclavecheckbox();
    }

    private void mostrarclavecheckbox() {
        mostrarclave.setChecked(true);
        mostrarclave.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (!isChecked) {
                    campocontraseñaI.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
                } else {
                    campocontraseñaI.setInputType(129);
                }
            }
        });
    }


    public void ingresologin() {
        final String CorreoUsuario = campocorreo.getText().toString();
        final String ContraseñaUsuario = campocontraseñaI.getText().toString();


        Response.Listener<String> responseListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);


                    boolean success = jsonResponse.getBoolean("success");
                    String nombre= jsonResponse.getString("nombre_empleado");
                   String telefono = jsonResponse.getString("telefono_empleado");

                    if (success) {
                        Intent Ingresar = new Intent(getApplicationContext(), PrincipalActivity.class);


                        Ingresar.putExtra("correo", CorreoUsuario);
                        Ingresar.putExtra("telefono", telefono);
                        Ingresar.putExtra("nombre", nombre);
                        startActivity(Ingresar);
                        campocorreo.setText("");
                        campocontraseñaI.setText("");
                    } else {
                        Toast.makeText(MainActivity.this, "Incorrecto", Toast.LENGTH_SHORT).show();
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setMessage("Usuario o Contraseña incorrecta")
                                .setNegativeButton("OK", null)
                                .create()
                                .show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        DatosLogin recepcionLogin = new DatosLogin(CorreoUsuario, ContraseñaUsuario, responseListener);
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(recepcionLogin);
    }


    public void BotonesInicio(View view) {
        switch (view.getId()) {
            case R.id.btnIngresoPrincipal:
                if (!campocorreo.getText().toString().isEmpty() && !campocontraseñaI.getText().toString().isEmpty()) {
                    ingresologin();
                } else {
                    Toast.makeText(this, "Campos Faltantes", Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.btnNuevoUsuario:
                Intent NuevoU = new Intent(getApplicationContext(), NuevoUsuarioActivity.class);
                startActivity(NuevoU);
                break;


        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_item, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item1:
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setMessage("S.P.E.T (Sistema de Pago Electronico del Transmetro), es una aplicacion creada para que el usuario pueda controlar, administrar y solicitar saldo para la utilizacion del sistema  de transporte municipal del metro (TRANSMETRO), facilitandole así el ingreso, ubicación y solicitud de crédito para transportarse.")
                        .setNegativeButton("OK", null)
                        .create()
                        .show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
