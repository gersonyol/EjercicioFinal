
package pf.sistema.modular;

import controlador.Accesos;
import controlador.Login;
import modelo.EmpleadosDAO;
import modelo.EmpleadosVO;
import vista.FrControl;
import vista.FrEmpleado;
import vista.FrLogin;

/**
 *
 * @author Chezter
 */
public class PFSistemaModular {


    public static void main(String[] args) {
        // TODO code application logic here
        FrLogin fl = new FrLogin();
        FrControl fc = new FrControl();
        FrEmpleado fe = new FrEmpleado();
        
        EmpleadosVO evo = new EmpleadosVO();
        EmpleadosDAO edao = new EmpleadosDAO();
        
        Login lo = new Login(fl, fc, evo, edao);
        Accesos ac = new Accesos(fc, evo, edao);
        
        fl.setVisible(true);
        fl.setLocationRelativeTo(null);
        
    }
    
}
