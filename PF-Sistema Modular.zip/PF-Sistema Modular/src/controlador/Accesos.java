/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.table.DefaultTableModel;
import modelo.EmpleadosDAO;
import modelo.EmpleadosVO;
import vista.FrControl;

/**
 *
 * @author Chezter
 */
public class Accesos implements ActionListener, WindowListener, MouseListener {

    FrControl fc = new FrControl();
    EmpleadosVO gvo = new EmpleadosVO();
    EmpleadosDAO gdao = new EmpleadosDAO();
    DefaultTableModel modelo = new DefaultTableModel();

    public Accesos(FrControl fc, EmpleadosVO gvo, EmpleadosDAO gdao) {

        this.fc = fc;
        this.gvo = gvo;
        this.gdao = gdao;

        fc.btnIngresar.addActionListener(this);
        fc.btnBorrar.addActionListener(this);
        fc.btnModificar.addActionListener(this);
        fc.btnSalir.addActionListener(this);
        fc.addWindowListener(this);
        fc.addMouseListener(this);
        fc.tblAdministrador.addMouseListener(this);
        fc.setLocationRelativeTo(null);

    }
    
    private void insertarUsuario(){
        gvo.setNombre_empleado(fc.txtNombreUsuario.getText());
        gvo.setMail_empleado(fc.txtCorreo.getText());
        gvo.setTelefono_empleado(fc.txtTel.getText());
        gvo.setPasswd_empleado(fc.txtPwd.getText());
        gvo.setId_tipo_empleado(fc.cmbTipoUsuario.getSelectedIndex());
        gvo.setId_estado(fc.cmbEstadoUsuario.getSelectedIndex());
       
        gdao.insertar(gvo);
        fc.optMensajeIngresar.showMessageDialog(null, " ¡Registro insertado correctamente! ");
    }
    
    private void mostrarDatos(){
        
        DefaultTableModel m = new DefaultTableModel();
        m.setColumnCount(0);
        m.addColumn("Id");
        m.addColumn("Nombre");
        m.addColumn("mail");
        m.addColumn("telefono");
        m.addColumn("Passwd");
        m.addColumn("Id_Tipo_Empleado");
        m.addColumn("Id_Estado");
        
        for (EmpleadosVO v : this.gdao.consultarTabla()) {
            m.addRow(new Object[]{v.getId_empleado(), v.getNombre_empleado(),
            v.getMail_empleado(), v.getTelefono_empleado(),
            v.getPasswd_empleado(), v.getId_tipo_empleado(), v.getId_estado()});
        }
        
        fc.tblAdministrador.setModel(m);
    }
    
   private void eliminarDatos(){
        this.gvo.getId_empleado();
        this.gdao.eliminar(gvo);
        fc.optMensajeBorrar.showMessageDialog(null, "¡Registro eliminado correctamente!");
    } 
   
   private void agregarDatosTxt(){
        int seleccion;
        seleccion = fc.tblAdministrador.getSelectedRow();
        gvo.setId_empleado((int)fc.tblAdministrador.getValueAt(seleccion, 0));
        fc.txtNombreUsuario.setText(String.valueOf(fc.tblAdministrador.getValueAt(seleccion, 1)));
        fc.txtCorreo.setText(String.valueOf(fc.tblAdministrador.getValueAt(seleccion, 2)));
        fc.txtTel.setText(String.valueOf(fc.tblAdministrador.getValueAt(seleccion, 3)));
        fc.txtPwd.setText(String.valueOf(fc.tblAdministrador.getValueAt(seleccion, 4)));
        fc.cmbTipoUsuario.setSelectedIndex((int)fc.tblAdministrador.getValueAt(seleccion, 5));
        fc.cmbEstadoUsuario.setSelectedIndex((int)fc.tblAdministrador.getValueAt(seleccion, 6));
    }
   
    private void modificarDatos(){
        
        gvo.getId_empleado();
        gvo.setNombre_empleado(fc.txtNombreUsuario.getText());
        gvo.setMail_empleado(fc.txtCorreo.getText());
        gvo.setTelefono_empleado(fc.txtTel.getText());
        gvo.setPasswd_empleado(fc.txtPwd.getText());
        gvo.setId_tipo_empleado(fc.cmbTipoUsuario.getSelectedIndex());
        gvo.setId_estado(fc.cmbEstadoUsuario.getSelectedIndex());
        
        gdao.modificar(gvo);
        fc.optMensajeModificar.showMessageDialog(null, "¡Registro modificado correctamente!");
    }
    
    public void limpiarTxt(){
        fc.txtNombreUsuario.setText("");
        fc.txtCorreo.setText("");
        fc.txtTel.setText("");
        fc.txtPwd.setText("");
        fc.cmbTipoUsuario.setSelectedIndex(0);
        fc.cmbEstadoUsuario.setSelectedIndex(0);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
         if ((e.getSource() == fc.btnIngresar)){                
            
            this.insertarUsuario();
            this.mostrarDatos();
            this.limpiarTxt();
        
        }if (e.getSource() == fc.btnBorrar) {
            
            this.eliminarDatos();
            this.mostrarDatos();
            this.limpiarTxt();
        }
        
        if (e.getSource() == fc.btnModificar) {
            
            this.modificarDatos();
            this.mostrarDatos();
            this.limpiarTxt();
        }
        
        if (e.getSource() == fc.btnSalir) {
            this.fc.dispose();
        }
        
       
    }
 

    @Override
    public void windowOpened(WindowEvent e) {
        this.mostrarDatos();
    }

    @Override
    public void windowClosing(WindowEvent e) {

    }

    @Override
    public void windowClosed(WindowEvent e) {

    }

    @Override
    public void windowIconified(WindowEvent e) {

    }

    @Override
    public void windowDeiconified(WindowEvent e) {

    }

    @Override
    public void windowActivated(WindowEvent e) {

    }

    @Override
    public void windowDeactivated(WindowEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {
        this.agregarDatosTxt();
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

}
