/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import modelo.EmpleadosDAO;
import modelo.EmpleadosVO;
import vista.FrControl;
import vista.FrEmpleado;
import vista.FrLogin;

/**
 *
 * @author Chezter
 */
public class Login implements ActionListener, WindowListener{
    
    FrLogin flog = new FrLogin();
    FrControl fcon = new FrControl();
    FrEmpleado fem = new FrEmpleado();
    EmpleadosVO gvo = new EmpleadosVO();
    EmpleadosDAO gdao = new EmpleadosDAO();

    public Login(FrLogin flog, FrControl fcon, EmpleadosVO gvo, EmpleadosDAO gdao) {
        
        this.flog = flog;
        this.fcon = fcon;
        this.fem = fem;
        
        this.flog.btnIniciar.addActionListener(this);
        this.flog.btnCancelar.addActionListener(this);
    }

//    @Override
//    public void actionPerformed(ActionEvent e) {
//
//    }
    
    public void Login() {

        this.gvo.setLoginEmpleado(flog.txtCorreo.getText());
        this.gvo.setLoginPassword(String.valueOf(flog.jpwPassword.getPassword()));
        gdao.consultarEmpleadoPass(gvo);
        gdao.consultarTipoEstado(gvo);

        if ((this.flog.txtCorreo.getText().isEmpty())
                || (String.valueOf(this.flog.jpwPassword.getPassword()).isEmpty())) {

            flog.optError.showMessageDialog(null, "¡Ingrese usuario y password!");

        } else if (gvo.getLoginEmpleado().equals(gvo.getMail_empleado())
                && gvo.getLoginPassword().equals(gvo.getPasswd_empleado())) {

            if (gvo.getId_estado() == 1) {
                switch (gvo.getId_tipo_empleado()) {
                    case 1:
                        flog.dispose();
                        fcon.setVisible(true);
                        fcon.setLocationRelativeTo(null);
                        break;
                    case 2:
                        flog.dispose();
                        fem.setVisible(true);
                        fem.setLocationRelativeTo(null);
                        break;
                }
                flog.optIngresoLogin.showMessageDialog(null, "Bienvenido");
            } else {
                flog.optUsuarioInactivo.showMessageDialog(null, "Usuario Inactivo, comuniquese con el administrador");
            }
        } else {
            flog.optErrorLogin.showMessageDialog(null, "Datos Incorrectos");
        }
    
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == flog.btnIniciar) {
            this.Login();
        }

        if (e.getSource() == flog.btnCancelar) {
            this.flog.dispose();
        }
    }

    @Override
    public void windowOpened(WindowEvent e) {
        
    }

    @Override
    public void windowClosing(WindowEvent e) {
        
    }

    @Override
    public void windowClosed(WindowEvent e) {
       
    }

    @Override
    public void windowIconified(WindowEvent e) {
       
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
        
    }

    @Override
    public void windowActivated(WindowEvent e) {
        
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
        
    }
    
}
