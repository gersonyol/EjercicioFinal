/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Chezter
 */
public class Conector {
    
    private String driver = "com.mysql.jdbc.Driver";
    //private String servidor = "127.1.1.0";
    private String servidor = "chez-mysql.mysql.database.azure.com";
    //private String usuario = "root";
    private String usuario = "chezter@chez-mysql";
    //private String password = "";
    private String password = "Intecap2020";
    private String bd = "db_sistema";
    private String cadena;
    
        Connection con;
        Statement st;
        
        public void conectar(){
        this.cadena = "jdbc:mysql://"+this.servidor+"/"+this.bd;
        
        try {
            
            Class.forName(this.driver).newInstance();
            this.con = DriverManager.getConnection(this.cadena, this.usuario, this.password);
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
                
    }
        
        public void desconectar(){
        
        try {
            con.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
        
        public int consultaMultiple(String consulta){
        int resultado;
        
        try {
            this.conectar();
            this.st = this.con.createStatement();
            resultado = this.st.executeUpdate(consulta);
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return 0;
        }
        
        return resultado;
    }
        
         public ResultSet consultaObtener (String consulta){
        
        try {
            this.conectar();
            ResultSet respuesta = null;
            this.st = this.con.createStatement();
            respuesta = st.executeQuery(consulta);
            
            return respuesta;
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        
        return null;
        
         }
    
    
}
