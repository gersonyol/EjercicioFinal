/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Chezter
 */
public class EmpleadosVO {
    
    private int id_empleado;
    private String nombre_empleado;
    private String mail_empleado;
    private String telefono_empleado;
    private String passwd_empleado;
    private int id_tipo_empleado;
    private int id_estado;
    private String loginEmpleado;
    private String loginPassword;

    public int getId_empleado() {
        return id_empleado;
    }

    public void setId_empleado(int id_empleado) {
        this.id_empleado = id_empleado;
    }

    public String getNombre_empleado() {
        return nombre_empleado;
    }

    public void setNombre_empleado(String nombre_empleado) {
        this.nombre_empleado = nombre_empleado;
    }

    public String getMail_empleado() {
        return mail_empleado;
    }

    public void setMail_empleado(String mail_empleado) {
        this.mail_empleado = mail_empleado;
    }

    public String getTelefono_empleado() {
        return telefono_empleado;
    }

    public void setTelefono_empleado(String telefono_empleado) {
        this.telefono_empleado = telefono_empleado;
    }

    public String getPasswd_empleado() {
        return passwd_empleado;
    }

    public void setPasswd_empleado(String password_empleado) {
        this.passwd_empleado = password_empleado;
    }

    public int getId_tipo_empleado() {
        return id_tipo_empleado;
    }

    public void setId_tipo_empleado(int id_tipo_empleado) {
        this.id_tipo_empleado = id_tipo_empleado;
    }

    public int getId_estado() {
        return id_estado;
    }

    public void setId_estado(int id_estado) {
        this.id_estado = id_estado;
    }

    public String getLoginEmpleado() {
        return loginEmpleado;
    }

    public void setLoginEmpleado(String loginEmpleado) {
        this.loginEmpleado = loginEmpleado;
    }

    public String getLoginPassword() {
        return loginPassword;
    }

    public void setLoginPassword(String loginPassword) {
        this.loginPassword = loginPassword;
    }
    
    
    
}
